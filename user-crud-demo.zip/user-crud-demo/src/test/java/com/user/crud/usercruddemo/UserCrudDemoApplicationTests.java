package com.user.crud.usercruddemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserCrudDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
